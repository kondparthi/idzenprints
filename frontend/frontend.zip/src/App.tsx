import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "@/auth/ProtectedRoute";
import AppLayout from "@/layouts/AppLayout";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Customers from "@/pages/Customers";
import CustomerForm from "@/pages/CustomerForm";
import DocumentUpload from "@/pages/DocumentUpload";
import DocumentDetail from "@/pages/DocumentDetail";
import CardTypes from "@/pages/CardTypes";
import Templates from "@/pages/Templates";
import TemplateDesigner from "@/pages/TemplateDesigner";
import CardGenerate from "@/pages/CardGenerate";
import Orders from "@/pages/Orders";
import Reports from "@/pages/Reports";
import Profile from "@/pages/Profile";
import ChangePassword from "@/pages/ChangePassword";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/customers" element={<Customers />} />
          <Route path="/customers/new" element={<CustomerForm />} />
          <Route path="/customers/:id" element={<CustomerForm />} />
          <Route path="/documents/upload" element={<DocumentUpload />} />
          <Route path="/documents/:id" element={<DocumentDetail />} />
          <Route path="/card-types" element={<CardTypes />} />
          <Route path="/templates" element={<Templates />} />
          <Route path="/templates/:id/design" element={<TemplateDesigner />} />
          <Route path="/cards/new" element={<CardGenerate />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/change-password" element={<ChangePassword />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
