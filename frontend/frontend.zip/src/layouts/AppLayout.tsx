import { useEffect, useRef, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/auth/AuthContext";
import "./AppLayout.css";

const NAV_ITEMS = [
  {
    to: "/",
    label: "Dashboard",
    end: true,
    icon: <path d="M4 13h6V4H4v9zM14 20h6v-9h-6v9zM4 20h6v-4H4v4zM14 10h6V4h-6v6" />,
  },
  {
    to: "/customers",
    label: "Customers",
    icon: <path d="M17 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />,
  },
  {
    to: "/orders",
    label: "Orders",
    icon: <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 13l2 2 4-4" />,
  },
  {
    to: "/card-types",
    label: "Card Types",
    icon: <path d="M2 7a2 2 0 012-2h16a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V7zM2 10h20M6 15h4" />,
  },
  {
    to: "/templates",
    label: "Templates",
    icon: <path d="M4 4h7v7H4zM13 4h7v7h-7zM13 13h7v7h-7zM4 13h7v7H4z" />,
  },
  {
    to: "/reports",
    label: "Reports",
    icon: <path d="M3 3v18h18M8 17V9M13 17V5M18 17v-6" />,
  },
];

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const initials = (user?.name ?? "?")
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  async function handleLogout() {
    setIsMenuOpen(false);
    await logout();
    navigate("/login", { replace: true });
  }

  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <div className="app-sidebar-brand">
          <span className="app-sidebar-logo-mark" aria-hidden="true"></span>
          IDZEN
        </div>
        <nav className="app-nav">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => "app-nav-link" + (isActive ? " active" : "")}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                {item.icon}
              </svg>
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="app-main">
        <header className="app-topbar">
          <div />
          <div className="app-topbar-user" ref={menuRef}>
            <button className="app-user-trigger" onClick={() => setIsMenuOpen((v) => !v)}>
              <span className="avatar">{initials}</span>
              <span className="app-user-trigger-text">
                <span className="app-user-name">{user?.name}</span>
                <span className="app-topbar-role">{user?.role.replace("_", " ")}</span>
              </span>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="app-user-chevron">
                <path d="M6 9l6 6 6-6" />
              </svg>
            </button>

            {isMenuOpen && (
              <div className="app-user-menu">
                <Link to="/profile" className="app-user-menu-item" onClick={() => setIsMenuOpen(false)}>
                  Profile
                </Link>
                <Link to="/change-password" className="app-user-menu-item" onClick={() => setIsMenuOpen(false)}>
                  Change password
                </Link>
                <button className="app-user-menu-item app-user-menu-danger" onClick={handleLogout}>
                  Log out
                </button>
              </div>
            )}
          </div>
        </header>
        <main className="app-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
